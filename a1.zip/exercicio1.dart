void main() {
  int a = 20;

  if (a % 5 == 0) {
    print('O número $a' ' é multiplicação');
  } else {
    print("O número $a não é multiplo de 5");
  }
}
