void main() {
  var num = 20;

  //Operador Ternário
  var mensagem =
      num % 2 == 0 ? 'O número $num é par.' : 'O número $num é ímpar.';

  //Imprimir a Mensagem
  print(mensagem);
}
