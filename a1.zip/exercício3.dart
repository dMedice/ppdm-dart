void main() {
  var num = 10;

  //Estrutura condicional
  if (num % 2 == 0) {
    print('O número $num é par. ');
  } else {
    print('O número $num é ímpar');
  }
}
