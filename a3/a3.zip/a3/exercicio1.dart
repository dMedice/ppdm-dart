void main() {
  List<double> numeros = [10.0, 8.0, 9.0, 7.0, 10.0, 7.5, 9.0, 9.4];

  // Calculando a soma dos números
  double soma = 0.0;
  for (double numero in numeros) {
    soma += numero;
  }

  // Calculando a média
  double media = soma / numeros.length;

  print('A média dos números é: ${media.toStringAsFixed(2)}');
}
