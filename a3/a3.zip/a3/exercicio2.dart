void main() {
  List<String> frutas = ["banana", "maçã", "laranja", "abacaxi", "kiwi"];

  // Ordenando a lista em ordem alfabética
  frutas.sort();

  // Exibindo as frutas ordenadas
  print("Frutas em ordem alfabética:");
  for (var fruta in frutas) {
    print(fruta);
  }
}
